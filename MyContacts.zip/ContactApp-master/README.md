# ContactApp
App is made on Java/Android Studio
You can save the contact information along with the image and also update the images, and other textfields.
DialogBox notices functioanlity is added. 
Enjoy
